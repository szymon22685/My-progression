﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankrekening
{
    class Program
    {
        static void Main(string[] args)
        {
            string BkNr = "";
            Boolean invoerOk = false;
            Int64 eerstenrs, middelstenrs, laatstenrs, controle, somEersteEnTweedenrs;
            while (invoerOk == false)
            {
                Console.WriteLine("Wat is uw bankrekeningnummer?");
                BkNr = Convert.ToString(Console.ReadLine());
                try
                {
                    eerstenrs = Convert.ToInt64(BkNr.Substring(0, 3));
                    middelstenrs = Convert.ToInt64(BkNr.Substring(4, 7));
                    laatstenrs = Convert.ToInt64(BkNr.Substring(12, 2));  //Bij dit moment gaat het niet meer en ik weet echt niet waar het fout ligt, ik ben al met dit meer dan een anderhalf uur bezig: System.ArgumentOutOfRangeException
                    somEersteEnTweedenrs = Int64.Parse(eerstenrs.ToString() + middelstenrs.ToString());
                    controle = somEersteEnTweedenrs % 97;
                    if (controle == laatstenrs)
                        invoerOk = true;

                    if (!invoerOk)
                    {
                        Console.WriteLine("Je moet wel een geldige nummer gebruiken anders werkt het niet!");
                        Console.ReadLine();
                    }
                }
                catch (FormatException fe)
                {
                    Console.WriteLine(fe);
                    Console.WriteLine("Je moet wel een geldige bankrekeningnummer geven, probeer nog een keer!");
                    Console.ReadLine();
                    invoerOk = false;
                }
                if (invoerOk == true)
                    Console.WriteLine("Je hebt een geldige bankrekeningnummer gegeven!");
                Console.ReadLine();
            }
        }
    }
}
