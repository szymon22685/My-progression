﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvenOfOneven
{
    class Program
    {
        static void Main(string[] args)
        {
            Int32 verzamelingEvenWorpen = 0;
            Int32[] HoeveelheidWorpen;
            HoeveelheidWorpen = new Int32[10];
            Int32 plusEen = 0, som = 0;
            if (IsEven() == true)
            {
                plusEen += 1;
                som += plusEen;
            }

            verzamelingEvenWorpen = som;

            for (int i = 0; i < HoeveelheidWorpen.Length; i++)
            {
                HoeveelheidWorpen[i] = GooidDobbelsteen();
            }
            if (verzamelingEvenWorpen >= 5 && verzamelingEvenWorpen <= 10)
            {
                Console.WriteLine("De test is goed afgelopen");
                Console.ReadLine();
            }
            else if (verzamelingEvenWorpen <= 4 && verzamelingEvenWorpen >= 0)
            {
                Console.WriteLine("De test is slecht afgelopen");
                Console.ReadLine();
            }
        }
        static Boolean IsEven()
        {
            Boolean even = false;
            Int32 Worp;
            Worp = GooidDobbelsteen();
            if (Worp == 2 || Worp == 4 || Worp == 6)
            {
                even = true;
            }
   
            return even;
        }
        static Int32 GooidDobbelsteen()
        {
            Int32 worp;
            Boolean worpOk = false;
            Console.WriteLine("Gooi met de dobbelsteen");
            worp = Convert.ToInt32(Console.ReadLine());
            while (!worpOk)
            {
                if (worp > 0 && worp < 7)
                {
                    worpOk = true;
                }
                else
                {
                    Console.WriteLine("Je hebt een ongeldig getal gegeven, hestart het programma");
                    Console.ReadLine();
                }           
            }
            return worp;
        }
    }
}
