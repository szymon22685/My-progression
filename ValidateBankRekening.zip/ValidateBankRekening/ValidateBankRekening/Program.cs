﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidateBankRekening
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            string rekeningNR = "";
            bool bankOK = false;
            Int64 eerste3, tweede7, laatste2, eerste10, rest;

            //setup
            Console.ForegroundColor = ConsoleColor.White;

            while (!bankOK)
            {
                //input
                Console.WriteLine("Geef een rekeningnummer.");
                rekeningNR = Console.ReadLine();
                try
                {
                    //getting numbers
                    eerste3 = Convert.ToInt64(rekeningNR.Substring(0, 3));
                    tweede7 = Convert.ToInt64(rekeningNR.Substring(4, 7));
                    laatste2 = Convert.ToInt64(rekeningNR.Substring(12, 2));
                    eerste10 = Int64.Parse(eerste3.ToString() + tweede7.ToString());

                    rest = eerste10 % 97;

                    if (rest == laatste2)
                        bankOK = true;

                    if (!bankOK)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write(rekeningNR);
                        Console.ForegroundColor = ConsoleColor.White;                        
                        Console.WriteLine(" is geen geldig rekeningnummer.");
                    }
            }
                catch (Exception)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(rekeningNR);
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(" is geen geldig rekeningnummer.");
                bankOK = false;
            }
        }
            Console.WriteLine($"\"{rekeningNR}\" is een geldig rekeningnummer.");
            Console.ReadLine();
        }
    }
}
