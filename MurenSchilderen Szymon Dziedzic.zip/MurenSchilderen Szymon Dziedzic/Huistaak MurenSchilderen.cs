﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MurenSchilderen
{
    class Program
    {
        static void Main(string[] args)
        {
            Double _lengte, _breedte, _hoogte, _opp1, _opp2, _opp3, _opptot, _slhd, _LVerf, _uren;
            Double _minuten, _seconden;
            Console.WriteLine("Geef de lengte van jouw kamer.");
            _lengte = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Geef de breedte van jouw kamer.");
            _breedte = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Geef de hoogte van jouw kamer.");
            _hoogte = Convert.ToDouble(Console.ReadLine());
            _opp1 = _lengte * _hoogte * 2;
            _opp2 = _breedte * _hoogte * 2;
            _opp3 = _breedte * _lengte;
            _opptot = _opp1 + _opp2 + _opp3;
            //Verf
            Console.WriteLine("Hoe snel ga je schilderen(in m² per uur)");
            _slhd = Convert.ToDouble(Console.ReadLine());
            _LVerf = _opptot / 5;
            //tijd
            _uren = _opptot / _slhd;
            //de tijd in uren is al bewerkt
            _minuten = _uren / 60;
            _seconden = _minuten / 60;
            //output
            Console.WriteLine(" Je gaat er " + _uren.ToString("0.0 uren") + " , " + _minuten.ToString("0.0 minuten") + " en " + _seconden.ToString("0.0 seconden over doen en je gaat " + _LVerf + " liter verf verbruiken"));
            Convert.ToString(Console.ReadLine());

        }
    }
}
