﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bowlen
{
    class Program
    {
        static void Main(string[] args)
        {
            Int32 eersteBal, tweedeBal;
            Int32 score = 0;
            string boodschap = "";
            Console.WriteLine("Hoeveel kegels heb je kunnen raken met je eerste bal?");
            eersteBal = Convert.ToInt32(Console.ReadLine());
          if (eersteBal == 10)
          { 
                eersteBal = score;
                boodschap = "Strike";
                Console.WriteLine(boodschap);
                Console.ReadLine();
          }
              //gutter   
            else
            Console.WriteLine("Hoeveel kegels heb je kunnen raken met de tweede bal");
            tweedeBal = Convert.ToInt32(Console.ReadLine());
            {
                if (eersteBal + tweedeBal == 0)
                boodschap = "Gutter";
                Console.WriteLine(boodschap);
                Console.ReadLine();
            }
            //spare    //vanaf hier doet het programma raar en u zal een paar keer op enter moeten drukken voor een resultaat       
            {
                if (eersteBal + tweedeBal == 10)
               boodschap = "Spare";
               Console.WriteLine(boodschap);
               Console.ReadLine();
            }
              //anders
            {
                if (eersteBal + tweedeBal != 10)
                Console.WriteLine("De som van de omgegooide kegels is {0:0}", eersteBal + tweedeBal);
                Console.ReadLine();
            }
        }
    }
}
