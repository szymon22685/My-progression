﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kleding
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaration and referenceing
            double totaalPrijs = TotaalPrijs();

            //Output
            Console.WriteLine($"Het gaat je {totaalPrijs} euro kosten");
            Console.ReadLine();
        }
        static double ProcentMaat()
        {
            //Declaration
            int maat;
            double procent = 0;
            bool invoerOK = false;

            //Clac
            while (!invoerOK)
            {
                try
                {
                    //Input
                    Console.WriteLine("Welke kledingmaat? (0 voor Small)(1 voor Medium)(2 voor Large)(3 voor Extra Large)");
                    maat = Convert.ToInt32(Console.ReadLine());
                    if (maat >= 0 && maat <= 3)
                    {
                        if (maat == 0)
                            procent = -0.05;
                        if (maat == 1)
                            procent = 0;
                        if (maat == 2)
                            procent = 0.05;
                        if (maat == 3)
                            procent = 0.1;
                        invoerOK = true;
                    }
                    else
                        Console.WriteLine("Voer een geldige waarde in.");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Voer een geldige waarde in.");
                }
            }
            //Output
            return procent;
        }
        static double ProcentStof()
        {
            //Declaration
            int stof;
            double procent = 0;
            bool invoerOK = false;

            //Calc
            while (!invoerOK)
            {
                try
                {
                    //Input
                    Console.WriteLine("Welke stof? (0 voor Katoen)(1 voor Zijde)(2 voor Wol)");
                    stof = Convert.ToInt32(Console.ReadLine());
                    if (stof >= 0 && stof <= 2)
                    {
                        if (stof == 0)
                            procent = 0;
                        if (stof == 1)
                            procent = 0.2;
                        if (stof == 2)
                            procent = 0.1;
                        invoerOK = true;
                    }
                    else
                        Console.WriteLine("Voer een geldige waarde in.");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Voer een geldige waarde in.");
                }
            }
            //Output
            return procent;
        }
        static double AantalStuks()
        {
            //Declaration
            double aantalStuks;

            //Input
            Console.WriteLine("Hoeveel T-shirts koop je aan?");
            aantalStuks = Convert.ToInt32(Console.ReadLine());

            //Output
            return aantalStuks;
        }
        static double TotaalPrijs()
        {
            //Declaration
            const int BASISPRIJS = 100;
            double totaalPrijs, maatProcent, stofProcent, maatPrijs, stofPrijs, aantalStuks;

            //Calc
            maatProcent = ProcentMaat();
            maatPrijs = BASISPRIJS * maatProcent;
            stofProcent = ProcentStof();
            stofPrijs = BASISPRIJS * stofProcent;
            totaalPrijs = BASISPRIJS + maatPrijs + stofPrijs;
            aantalStuks = AantalStuks();
            totaalPrijs *= aantalStuks;

            //Output
            return totaalPrijs;
        }
    }
}
