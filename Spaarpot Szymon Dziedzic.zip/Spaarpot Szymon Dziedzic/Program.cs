﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaarpot
{
    class Program
    {
        static void Main(string[] args)
        {
            string deDing;
            Int32 geld, geldsom, geldExtra, geldOverbodig;
            Console.WriteLine("Waar wil je voor sparen?");
            deDing = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Hoeveel ga je ervoor moeten betalen?(in euro)");
            geld = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Hoeveel geld heb je al in je spaarpot?(in euro)");
            geldsom = Convert.ToInt32(Console.ReadLine());
            while (geldsom < geld)
            { 
                Console.WriteLine("Steek nog wat geld in de spaarpot(in euro)");
                geldExtra = Convert.ToInt32(Console.ReadLine());
                geldsom += geldExtra;
                if (geld < geldsom)
                {
                    Console.WriteLine("Je hebt genoeg geld kunnen sparen voor: " + deDing);
                    Console.ReadLine();
                }
            }
            geldOverbodig = geldsom - geld;
            Console.WriteLine("En je hebt nog zoveel geld over: " + geldOverbodig + "!");
            Console.ReadLine();
        }
    }
}
