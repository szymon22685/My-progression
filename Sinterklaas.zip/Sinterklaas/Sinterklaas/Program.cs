﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sinterklaas
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] wishlist = AskWishList();
            Console.WriteLine("Dit zijn de dingen die je werkelijk gaat krijgen");
            ActualPresetns(wishlist);
            Console.ReadLine();
        }
        static string[] AskWishList()
        {
            Console.WriteLine("Geef je verlanglijstje, alle artiekels gescheiden door een komma.");
            string itemsOnList = Console.ReadLine();
            string[] wishlist = itemsOnList.Split(',');
            return wishlist;
        }
        static void ActualPresetns(string[] wishlist)
        {
            Random random = new Random();
            for (int i = 0; i < wishlist.Length; i++)
            {
                if (random.Next(0, 2) == 1)
                {
                    Console.WriteLine(wishlist[i]);
                }
                /*if (wishlist[i].ToLower().Contains("a") && 
                    wishlist[i].ToLower().Contains("e"))
                {
                    Console.WriteLine(wishlist[i]);
                }*/
            }
        }
    }
}
