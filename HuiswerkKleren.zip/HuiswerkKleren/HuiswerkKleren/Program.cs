﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HuiswerkKleren
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Jouw aankoop gaat je {0} euro kosten", EindPrijs());
            Console.ReadLine();
        }

        static Double MProcent()
        {
            Boolean invoerOk = false;
            Double maatprocent = 0;
            Int32 maat;
            while (!invoerOk)
            {
                try
                {
                    Console.WriteLine("Welke grote van u T-shirt wenst u te hebben (0 voor een S, 1 voor een M, 2 voor een L en 3 voor een XL");
                    maat = Convert.ToInt32(Console.ReadLine());
                    if (maat >= 0 && maat <= 3)
                    {
                        invoerOk = true;
                        if (maat == 0)
                            maatprocent = -0.05;
                        if (maat == 1)
                            maatprocent = 0;
                        if (maat == 2)
                            maatprocent = 0.05;
                        if (maat == 3)
                            maatprocent = 0.10;
                        invoerOk = true;
                    }
                    else
                        Console.WriteLine("Je hebt een fout getal ingegeven, probeer opnieuw");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Je hebt een fout getal ingegeven, probeer opnieuw");
                }
            }    
                
            return maatprocent;
        }

        static Double SProcent()
        {
            Boolean invoerOk = false;
            Double stofprocent = 0;
            Int32 stof;
            while (!invoerOk)
            {
                try
                {
                    Console.WriteLine("Van welke stof wenst u uw T-shirt gemaakt te hebben? (0 voor katoen, 1 voor zijde, 2 voor wol");
                    stof = Convert.ToInt32(Console.ReadLine());
                    if (stof >= 0 && stof <= 2)
                    {
                        invoerOk = true;
                        if (stof == 0)
                            stofprocent = 0;
                        if (stof == 1)
                            stofprocent = 0.10;
                        if (stof == 2)
                            stofprocent = 0.20;
                        invoerOk = true;
                    }
                    else
                    
                        Console.WriteLine("Je hebt een fout getal ingegeven, probeer opnieuw");
                    
                }
                catch (FormatException)
                {
                    Console.WriteLine("Je hebt een fout getal ingegeven, probeer opnieuw");
                }
            }
            return stofprocent;
        }

        static Double hoeveelheidTShirts()
        {
            
            Double aantaltshirts;
            Console.WriteLine("Hoeveel T-shirts wenst u te kopen?");
            aantaltshirts = Convert.ToDouble(Console.ReadLine());
            
            return aantaltshirts;
        }

        static Double EindPrijs()
        {
            Double prijs = 100;
            Double maatprocent, stofprocent, aantaltshirts, SomProcenten, eindPrijs, StukPrijs, ExtraBedrag;
            maatprocent = MProcent();
            stofprocent = SProcent();
            aantaltshirts = hoeveelheidTShirts();
            SomProcenten = maatprocent + stofprocent;
            ExtraBedrag = prijs * SomProcenten;
            StukPrijs = prijs + ExtraBedrag;
            eindPrijs = aantaltshirts * StukPrijs;

            return eindPrijs;

        }
        
    }
}
