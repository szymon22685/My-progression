﻿using System;

namespace KledijOef
{
    class Program
    {
        static void Main(string[] args)
        {
            double prijseinde = totaalprijs();
            Console.WriteLine("uw uiteindelijke prijs is {0} euro", prijseinde);
            Console.ReadLine();
        }
        static double aantalstuks()
        {
            double aantalkleren = 0;
            bool invoerok = false;
            while (!invoerok)
            {
                try
                {
                    Console.WriteLine("geef een aantal kleren");
                    aantalkleren = Convert.ToDouble(Console.ReadLine());
                    if (aantalkleren <= 0)
                        Console.WriteLine("uw invoer is ongeldig, probeer opnieuw");
                    else
                        invoerok = true;
                }
                catch (Exception)
                {
                    Console.WriteLine("uw invoer is ongeldig, probeer opnieuw");
                }
            }
            return aantalkleren;
        }
        static double Procentstof()
        {
            string stof;
            double procent = 0;
            bool invoerok = false;
            while (!invoerok)
            {
                Console.WriteLine("Van welke stof is uw kledij gemaakt? (Kies uit: katoen, zijde of wol)");
                stof = Convert.ToString(Console.ReadLine());
                stof = stof.ToLower();
                if (stof == "katoen" || stof == " zijde" || stof == "wol")
                {
                    invoerok = true;
                    switch (stof)
                    {
                        case "katoen":
                            procent = 0;
                            break;
                        case "zijde":
                            procent = 0.2;
                            break;
                        case "wol":
                            procent = 0.1;
                            break;
                        default:
                            break;
                    }
                }
                else
                    Console.WriteLine("deze invoer is ongeldig, probeer opnieuw");
            }

            return procent;
        }
        static double Procentmaat()
        {
            string maat;
            double procent = 0;
            bool invoerok = false;
            while (!invoerok)
            {
                Console.WriteLine("Welke maat zijn de kleren die je aankoopt (Kies uit: s, m, l, xl)");
                maat = Convert.ToString(Console.ReadLine());
                maat = maat.ToLower();
                if (maat == "s" || maat == "m" || maat == "x" || maat == "l" )
                {
                    invoerok = true;
                    switch (maat)
                    {
                        case "s":
                            procent = 0.05;
                            break;
                        case "m":
                            procent = 0;
                            break;
                        case "l":
                            procent = 0.05;
                            break;
                        case "xl":
                            procent = 0.1;
                            break;
                        default:
                            break;
                    }
                }
                else
                    Console.WriteLine("deze invoer is ongeldig, probeer opnieuw");
            }
            return procent;

        }
    static double totaalprijs()
    {
        double basisprijs = 100, prijszonderkosten, prijsstof, prijsmaat, totaalprijs;
        prijszonderkosten = aantalstuks() * basisprijs;
        prijsstof = prijszonderkosten * Procentstof();
        prijsmaat = prijszonderkosten * Procentmaat();
        totaalprijs = prijszonderkosten + prijsmaat + prijsstof;
        return totaalprijs;
    }
}
}